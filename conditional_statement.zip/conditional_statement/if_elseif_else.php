<?php

    echo "<h1 style='text-align: center; color: green'>If Elseif Else Condition</h1>";

$A =23;   
if($A <= "12"){
    echo "Good  morning <br>"; 
}
elseif($A<='17'){
echo "Good After Noon <br>"; 
}
elseif ($A<='22') {
    echo "Good Evening <br>";
}
else{
    echo "Good Night <br>";
}
?>