<?php    
    for($i=1;$i<=20;$i++){    
    echo "$i <br/>";    
        if($i==5){    
        break;    
        }    
    }   
?> 
<br>

<?php    
    for($i=1;$i<=3;$i++){    
    for($j=1;$j<=3;$j++){    
    echo "$i   $j<br/>";    
    if($i==2 && $j==2){    
    break;    
    }    
    }    
    }    
?> 