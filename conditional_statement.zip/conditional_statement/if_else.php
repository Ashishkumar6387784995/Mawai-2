<?php

    echo "<h1 style='text-align: center; color: green'>If Condition</h1>";

$A =5;   
if($A == "5"){
    echo "True <br>"; 
}
else{
echo "False <br>"; 
}


?>