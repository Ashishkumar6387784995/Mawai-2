<?php        
    $num=110;        
    switch($num){        
    case 100:        
    echo("number is equals to 100");        
    break;        
    case 200:        
    echo("number is equal to 200");        
    break;        
    case 300:        
    echo("number is equal to 300");        
    break;       
    default:        
    echo("number is not equal to 100, 200 or 500");        
    }       
?>
