<?php    
$emp = [
  [1,"Ashish",400000], 
  [2,"Suman", 500000],  
  [3,"Deepak",300000]
];
echo $emp[0][1]."</br>";  

for ($row = 0; $row < 3; $row++) {  
  for ($col = 0; $col < 3; $col++) {  
    echo $emp[$row][$col]."  ";  
  }  
  echo "<br/>";  
}  


echo "<pre>";
print_r($emp); 


$x=0;
while ($x<=5) {
  echo "$x </br>";
  if($x==5){
    echo "</br>";
  }
  $x++;
}
?>