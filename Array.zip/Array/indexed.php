<?php  
$size=array("Big","Medium","Short");  
echo "Size: $size[0], $size[1] and $size[2]";
echo "</br>"; 
echo "</br>"; 
?> 

<?php  
$size[0]="Big";  
$size[1]="Medium";  
$size[2]="Short";  
echo "Size: $size[0], $size[1] and $size[2]";  
echo "</br>";
echo "</br>";
?>

<?php  
$size=array("Big","Medium","Short");  
foreach( $size as $s )  
{  
  echo "Size is: $s<br />";  
}  
echo "</br>";
echo "</br>";
?> 

<?php  
$size=array("Big","Medium","Short");  
echo count($size);  
?>  