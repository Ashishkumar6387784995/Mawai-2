<?php    
$n=1;    
while($n<=10){    
echo "$n ";    
$n++;    
}    
echo "<br>";
?>  

<?php  
    $i = 'A';  
    while ($i <= 'H') {  
        echo $i;  
        $i++;  
        echo " ";  
    }  
    echo "<br>";
?> 


<?php    
$n=1;    
while($n<=10):    
echo "$n ";    
$n++;    
endwhile; 
echo "<br>";   
?>

